﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TaskManagement.BLL;
using TaskManagement.DAL;
using TaskManagement.DTO;

namespace TaskManagement
{
    public partial class SprintForm : Form
    {
        private string Mode;
        private Project currentProject;
        private int currentProjectID;

        private ProjectShowBLL bll = new ProjectShowBLL();
        private SprintShowBLL sprintbll = new SprintShowBLL();
        Project p = new Project();
        public ucProjectShowDashboard show = new ucProjectShowDashboard();

        public SprintForm()
        {
            InitializeComponent();
        }
        public SprintForm(string mode)
        {
            InitializeComponent();
            Mode = mode;
            ConfigureButtons();
        }

        private void ConfigureButtons()
        {
            btnSprintAdd.Enabled = false;
            btnSprintEdit.Enabled = false;
            btnSprintDelete.Enabled = false;
            switch (Mode)
            {
                case "Add":
                    btnSprintAdd.Enabled = true;
                    lblSpintID.Visible = false;    
                    btnSprintEdit.Visible = false;
                    btnSprintDelete.Visible = false;
                    break;
                case "Edit":
                    btnSprintEdit.Enabled = true;
                    txtSprintIdAdd.Visible = false;
                    lblSpintID.Visible = true;
                    btnSprintAdd.Visible = false;
                    btnSprintDelete.Visible = false;
                    break;
                case "Delete":
                    btnSprintDelete.Enabled = true;
                    txtSprintIdAdd.Visible = false;
                    btnSprintEdit.Visible = false;
                    btnSprintAdd.Visible = false;
                    break;
            }
        }

        private void SprintForm_Load(object sender, EventArgs e)
        {
            LoadUserList();
        }
        //Load danh sach Projects
        //Load danh sach User vao CheckedListBox
        private void LoadUserList()
        {
            List<User> users = bll.GetAllUsers();
            if (users != null && users.Count > 0)
            {
                clbSprintUsers.Items.Clear();
                List<User> userList = bll.GetAllUsers();
                foreach (var user in users)
                {
                    clbSprintUsers.Items.Add(user.FullName, false);
                }
            }
            else
            {
                MessageBox.Show("No users found.");
            }
        }
        public void SetAddMode(Project project)
        {
            Mode = "Add";
            currentProject = project;
            
            ConfigureButtons();

            lblProjectIDName.Text = $"{project.ProjectID} - {project.ProjectName}";
            lblProjectIDName.Visible = true;

            lblDept.Text = project.DepartmentName;
            //Range for Sprint Start and End Date
            dtpSprintStart.MinDate = project.StartDate;
            dtpSprintStart.MaxDate = project.DueDate;

            dtpSprintEnd.MinDate = project.StartDate;
            dtpSprintEnd.MaxDate = project.DueDate;
            //Load Project's Users list into CheckedListBox
            clbSprintUsers.Items.Clear();
            List<int> userIds = bll.GetUserIDsByProject(project.ProjectID);
            List<User> allUsers = bll.GetAllUsers();
            foreach (var user in allUsers)
            {
                if (userIds.Contains(user.UserID))
                {
                    clbSprintUsers.Items.Add(user.FullName, false); // không check
                }
            }
        }

        private void btnSprintAdd_Click(object sender, EventArgs e)
        {
            Sprint s = new Sprint
            {
                SprintID = int.Parse(txtSprintIdAdd.Text),
                SprintName = txtSprintName.Text,
                Description = txtSprintBacklog.Text,
                StartDate = dtpSprintStart.Value,
                EndDate = dtpSprintEnd.Value,
                ProjectID = currentProject.ProjectID,
                Status = "Dang thuc hien"
            };

            bool result = sprintbll.AddSprint(s);

            if (currentProject.ProjectID == 0)
            {
                MessageBox.Show("Lỗi: Chưa gán Project hợp lệ cho Sprint!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            if (result)
            {
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            else
            {
                MessageBox.Show("Add failed!");
            }
        }

    }
}
