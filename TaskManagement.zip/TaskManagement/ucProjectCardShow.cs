﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TaskManagement.DTO;

namespace TaskManagement
{
    public partial class ucProjectCardShow : UserControl
    {
        private ProjectShowBLL bll = new ProjectShowBLL();
        public ucProjectCardShow()
        {
            InitializeComponent();
            LoadProjectCardsToPanel();
        }

        public void LoadProjectCardsToPanel()
        {
            flpProjectCards.Controls.Clear();
            ProjectShowBLL bll = new ProjectShowBLL();
            List<Project> projects = bll.GetProjectsWithStats();

            foreach (var p in projects)
            {
                var card = new ProjectCard();
                card.LoadData(p);

                card.DetailsRequested += (s, e) =>
                {
                    var form = new DetailShow(p);
                    form.ShowDialog();
                };
                //card.EditRequested += (s, e) => OpenProjectForm("Edit", p.ProjectID);
                card.DeleteRequested += (s, e) =>
                {
                    DialogResult result = MessageBox.Show(
                    "Bạn có chắc chắn muốn xóa dự án này không?",
                    "Xác nhận xóa",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning
                    );
                    if (result == DialogResult.Yes)
                    {
                        bll.DeleteUsersFromProjects(p.ProjectID);
                        bool success = bll.DeleteProject(p.ProjectID);
                        if (success)
                        {
                            MessageBox.Show("Xóa thành công.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            LoadProjectCardsToPanel();
                        }
                        else
                        {
                            MessageBox.Show("Xóa thất bại!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                };
                card.EditRequested += (s, e) =>
                {
                    ProjectForm form = new ProjectForm();
                    form.SetEditMode(p.ProjectID);
                    if (form.ShowDialog() == DialogResult.OK)
                    {
                        LoadProjectCardsToPanel();
                    }
                };
                card.AddSprintRequested += (s, e) =>
                {
                    SprintForm form = new SprintForm();
                    form.SetAddMode(p); // p là Project của card hiện tại
                    if (form.ShowDialog() == DialogResult.OK)
                    {
                        MessageBox.Show("Thêm Sprint thành công.");

                        // Nếu đang xem Sprint, reload lại
                        var dashboard = this.FindForm() as DashboardForm;
                        if (dashboard != null)
                        {
                            dashboard.ucDashboard1.HandleButtonClick(dashboard.ucDashboard1.btnSprints);

                            var sprintUC = new ucSprintCardShow();
                            sprintUC.Dock = DockStyle.Fill;
                            sprintUC.LoadByProject(p);

                            dashboard.pnlShow.Controls.Clear();
                            dashboard.pnlShow.Controls.Add(sprintUC);
                        }
                    }
                };


                card.ViewSprintsClicked += (s, e) =>
                {
                    var dashboard = this.FindForm() as DashboardForm;
                    if (dashboard != null)
                    {
                        // 1. Đánh dấu nút Sprint là "được chọn"
                        //dashboard.ucDashboard1.HandleButtonClick(dashboard.ucDashboard1.btnSprints);

                        // 2. Tạo và add ucSprintCardShow mới
                        var sprintUC = new ucSprintCardShow();

                        dashboard.ShowSprintFromProject(p);
                    }
                };



                flpProjectCards.Controls.Add(card);
            }
        }
    }
}
